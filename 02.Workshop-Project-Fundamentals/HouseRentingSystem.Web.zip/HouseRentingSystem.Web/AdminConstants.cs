﻿namespace HouseRentingSystem.Web
{
    public class AdminConstants
    {
        public const string AdminRoleName = "Administrator";
        public const string AdminEmail = "admin@mail.com";
    }
}
