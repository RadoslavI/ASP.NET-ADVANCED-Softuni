﻿namespace HouseRentingSystem.Web.Models.Home
{
    public class IndexViewModel
    {
    }
}
