﻿namespace HouseRentingSystem.Services.Users
{
    public interface IUserService
    {
        string UserFullName(string userId);
    }
}
