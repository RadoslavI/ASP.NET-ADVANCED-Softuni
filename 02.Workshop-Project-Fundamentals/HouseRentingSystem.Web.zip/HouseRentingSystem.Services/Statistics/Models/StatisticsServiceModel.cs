﻿namespace HouseRentingSystem.Services.Statistics.Models
{
    public class StatisticsServiceModel
    {
        public int TotalHouses { get; init; }
        public int TotalRents { get; init; }
    }
}
