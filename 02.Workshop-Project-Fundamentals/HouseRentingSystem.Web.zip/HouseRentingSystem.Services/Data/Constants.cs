﻿namespace HouseRentingSystem.Services.Data
{
    public static class Constants
    {
        public const string AdminEmail = "admin@mail.com";
    }
}
