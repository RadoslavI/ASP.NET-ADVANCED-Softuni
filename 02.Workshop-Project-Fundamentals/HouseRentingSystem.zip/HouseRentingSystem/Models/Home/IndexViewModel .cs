﻿namespace HouseRentingSystem.Models.Home
{
    public class IndexViewModel
    {
    }
}
