﻿namespace HouseRentingSystem.Services.Houses.Models
{
    public interface IHouseModel
    {
        public string Title { get; }
        public string Address { get; }
    }
}
