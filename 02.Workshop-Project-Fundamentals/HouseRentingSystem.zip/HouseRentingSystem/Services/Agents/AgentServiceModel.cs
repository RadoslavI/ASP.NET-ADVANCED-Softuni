﻿namespace HouseRentingSystem.Services.Agents
{
    public class AgentServiceModel
    {
        public string PhoneNumber { get; set; }

        public string Email { get; set; }
        public string FullName { get; init; }
    }
}
